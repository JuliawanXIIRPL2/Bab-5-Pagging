<?php
include 'koneksi.php';?>
<h1 align="center" style="font-family: Arial"> Data Masjid </h1>

<style>
		* {
  font-family: sans-serif; 
}

.content-table {
  border-collapse: collapse;
  margin-top: 50px;
  margin-left: 300px;
  font-size: 0.9em;
  min-width: 400px;
  border-radius: 5px 5px 0 0;

}

.content-table thead tr {

  background-color: #009879;
  color: #ffffff;
  text-align: left;
  font-weight: bold;
}

.content-table th,
.content-table td {
  padding: 15px 30px;
}

.content-table tbody tr {
  border-bottom: 1px solid #dddddd;
}

.content-table tbody tr:nth-of-type(even) {
  background-color: #f3f3f3;
}

.content-table tbody tr:last-of-type {
  border-bottom: 2px solid #009879;
}

.content-table tbody tr.active-row {
  font-weight: bold;
  color: #009879;
}
		}
	</style>

	<table class="content-table">
<thead>
<tr> 
	<th>No</th>
	<th>Nama</th>
	<th>Alamat</th>
	<th>Kecamatan</th>
</tr>
</thead>
 
<?php
 
 $halaman = 10;
 $page = isset($_GET["halaman"]) ? (int)$_GET["halaman"] : 1;
 $mulai = ($page>1) ? ($page * $halaman) - $halaman : 0;
 $result = mysqli_query($koneksi,"SELECT * FROM tb_masjid");
 $total = mysqli_num_rows($result);
 $pages = ceil($total/$halaman);
 $query = mysqli_query($koneksi,"select * from tb_masjid LIMIT $mulai, $halaman")or
die(mysqli_error);

 $nomor = $mulai+1;
 while ($data = mysqli_fetch_assoc($query)) {
 
 ?>

<tbody>
 <tr> 
 	<td><?php echo $nomor++; ?></td>
	<td><?php echo $data['Nama_msj']; ?></td>
	<td><?php echo $data['Alamat'];?></td>
	<td><?php echo $data['Kecamatan'];?></td>
 </tr>
</tbody>
 
 <?php } ?>
 
 </table>
<div class="">
 <?php for ($i=1; $i<=$pages ; $i++) { ?>
 <a href="?halaman=<?php echo $i; ?>"><?php echo $i; ?></a>
 <?php } ?>
</div>