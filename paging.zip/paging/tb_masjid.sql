-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Apr 2021 pada 05.00
-- Versi server: 10.4.18-MariaDB
-- Versi PHP: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `program_sederhana`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_masjid`
--

CREATE TABLE `tb_masjid` (
  `id` int(11) NOT NULL,
  `Nama_msj` varchar(50) NOT NULL,
  `Alamat` text NOT NULL,
  `Kecamatan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_masjid`
--

INSERT INTO `tb_masjid` (`id`, `Nama_msj`, `Alamat`, `Kecamatan`) VALUES
(1, 'AL Ikhlas', 'Patal', 'Pameungpeuk'),
(2, 'AL Mumin', 'Patal', 'Pameungpeuk'),
(3, 'Nurul Falah', 'Sawah Luhur', 'Pameungpeuk'),
(4, 'Fisabilillah', 'Bojong Manggu', 'Pamengpeuk'),
(5, 'An-Nur', 'Cisangkuy', 'Pamengpeuk'),
(6, 'AL Fitroh', 'Komp GPA', 'Baleendah'),
(7, 'AL Amin', 'Bojong Manggu', 'Pameungpeuk'),
(8, 'Darusalam', 'Cisangkuy', 'Pameungpeuk'),
(9, 'Masjid Agung Al-Ikram', 'Bandung', 'Dayeuhkolot'),
(10, 'As-Syifa', 'Bandung', 'Ciparay'),
(11, 'Al Majid', 'Kertaharja', 'Ciparay'),
(12, 'As-Salam', 'Komp Permata', 'Ciparay'),
(13, 'Al-Ihsan', 'Cipaku', 'Banjaran'),
(14, 'Al-Hikmah', 'Bandung', 'Banjaran'),
(15, 'Assurur', 'Bojong Pulus', 'Banjaran'),
(16, 'Al Insan', 'Bojong Sereh', 'Banjaran'),
(17, 'Attaubah', 'Cikole', 'Rancamanyar'),
(18, 'AD duha', 'Rancamanyar', 'Rancamanyar'),
(19, 'Masjid Agung Bandung', 'JL Asia Afrika', 'Bandung'),
(20, 'Masjid Agung Banjaran', 'Banjaran', 'Banjaran');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_masjid`
--
ALTER TABLE `tb_masjid`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_masjid`
--
ALTER TABLE `tb_masjid`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
